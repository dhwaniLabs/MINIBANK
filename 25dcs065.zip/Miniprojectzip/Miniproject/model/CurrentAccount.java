package model;
import exception.InvalidAmountException;

public class CurrentAccount extends Account {
    private static final long serialVersionUID = 1L;
    private long overdraftLimit;

    public CurrentAccount(String owner, long opening, long overdraftLimit) {
        super(owner, opening, "Current");
        if (overdraftLimit < 0)
            throw new IllegalArgumentException("Overdraft cannot be negative");
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public double interestRate() {
        return 0.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return amount > 0 && getBalance() - amount >= -overdraftLimit;
    }

    public long getOverdraftLimit() {
        return overdraftLimit;
    }
}
